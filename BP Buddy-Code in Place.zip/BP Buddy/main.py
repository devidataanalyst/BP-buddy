def main():
    welcome_message = "WELCOME TO BP MONITORING CONSOLE"
    print(welcome_message)
    print(" ")

    patients = [
    {"name": "John Doe", "age": 34, "blood_pressure": 120},
    {"name": "Jane Smith", "age": 45, "blood_pressure": 130},
    {"name": "Tom Brown", "age": 23, "blood_pressure": 118},
    {"name": "Lisa Ray", "age": 55, "blood_pressure": 140},
    {"name": "Nina White", "age": 60, "blood_pressure": 150},
    {"name": "Sam Green", "age": 50, "blood_pressure": 135},
    {"name": "Emily Black", "age": 28, "blood_pressure": 125},
    {"name": "Alex Blue", "age": 40, "blood_pressure": 128},
    {"name": "Chris Yellow", "age": 37, "blood_pressure": 122},
    {"name": "Pat Purple", "age": 48, "blood_pressure": 132},
    ]

    for patient in patients:
        print(f'Name:{patient["name"]}')
        print(f'Age:{patient["age"]}')
        print(f'BP:{patient["blood_pressure"]}')
        print(" ")

    while True:
        print("Options : Average Age, Average BP, Max BP, Min BP, Warn, Search, Add, Exit")
        command = input("Enter Command: ")
        total_age = 0
        if command == "Average Age":
            for patient in patients:
                total_age += patient["age"]
                Average_Age = total_age/len(patients)
                Rounded_Value = round(Average_Age,2)
            print (f"Average Age = {Rounded_Value}")

        elif command == "Average BP":
            total_BP = 0
            for patient in patients:
                total_BP += patient["blood_pressure"]
                Average_BP = total_BP/ len(patients)
                Rounded_BP = round(Average_BP,2)
            print(f"Average BP = {Rounded_BP}")

        elif command == "Max BP":
            max_BP = max(patient["blood_pressure"] for patient in patients)
            print(f"Highest BP = {max_BP}")

        elif command == "Min BP":
            min_BP = min(patient["blood_pressure"] for patient in patients)
            print(f"Lowest BP = {min_BP}")

        elif command == "Warn":
            print("Blood Pressure Warning!!!")
            for patient in patients:
                bp = patient["blood_pressure"]
                if bp > 140:
                    print(f"High BP: {patient['name']} - {bp}")
                elif bp < 90:
                    print(f"Low BP: {patient['name']} - {bp}")

        elif command == "Search":
            target = input("Enter patient name: ") 
            found = False
            for patient in patients:
                if patient["name"] == target:
                    print(f'{patient["name"]}, Age: {patient["age"]}, BP: {patient["blood_pressure"]}')
                    found = True
            if not found:
                print("Not found!") 
        
        elif command == "Add":
            name = input("Enter name: ")
            age = int(input ("Enter age: "))
            BP = int(input("Enter blood_pressure: "))
            patients.append({"name": name, "age": age, "blood_pressure": BP})
            print("Patient Added!")

        elif command == "Exit":
            print("Thank You!")
            break
            
        else:
            print("Invalid command. Please try again.")


if __name__ == "__main__":
    main()